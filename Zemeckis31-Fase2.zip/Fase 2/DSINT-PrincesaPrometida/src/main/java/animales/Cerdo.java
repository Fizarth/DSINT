package animales;

import lugares.Lugar;

public class Cerdo extends Animal {

	public Cerdo(Lugar l ) {
		super("Cerdo", l);
	}

}
