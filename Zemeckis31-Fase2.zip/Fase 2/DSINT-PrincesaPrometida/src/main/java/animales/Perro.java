package animales;

import lugares.Lugar;

public class Perro extends Animal {

	public Perro(Lugar l ) {
		super("Perro",l);
	}

}
