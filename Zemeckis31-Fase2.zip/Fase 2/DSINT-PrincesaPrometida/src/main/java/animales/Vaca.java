package animales;

import lugares.Lugar;

public class Vaca extends Animal {

	public Vaca(Lugar l) {
		super("Vaca", l);
	}

}
