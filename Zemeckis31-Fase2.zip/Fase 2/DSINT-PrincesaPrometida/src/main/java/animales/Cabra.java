package animales;

import lugares.Lugar;

public class Cabra extends Animal {

	public Cabra(Lugar l) {
		super("Cabra", l);
	}

}
