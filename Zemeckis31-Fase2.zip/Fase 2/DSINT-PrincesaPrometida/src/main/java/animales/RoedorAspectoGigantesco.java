package animales;

import lugares.Lugar;

public class RoedorAspectoGigantesco extends Animal {

	public RoedorAspectoGigantesco(Lugar l) {
		super("Roedor de Aspecto Gigantesco",l);
	}

}
