package animales;

import lugares.Lugar;

public class Caballo extends Animal {

	public Caballo(Lugar l) {
		super("Caballo", l);
		
	}

}
