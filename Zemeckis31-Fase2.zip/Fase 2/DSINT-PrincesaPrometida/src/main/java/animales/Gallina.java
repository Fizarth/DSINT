package animales;

import lugares.Lugar;

public class Gallina extends Animal {

	public Gallina(Lugar l) {
		super("Gallina",l);
	}

}
