package animales;

import lugares.Lugar;

public class AnguilaElectrica extends Animal {

	public AnguilaElectrica(Lugar l) {
		super("Anguila Eléctrica",l);
	}

}
