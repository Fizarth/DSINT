package profesiones;

public class Mercenario extends Profesion {

	public Mercenario() {
		super("mercenario");
	}

}
