package profesiones;

public class Visir extends Profesion {

	public Visir() {
		super("visir");
	}

}
