package profesiones;

public class Curandero extends Profesion {

	public Curandero() {
		super("curandero");
	}

}
