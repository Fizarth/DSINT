package profesiones;

public class Granjero extends Profesion {

	public Granjero() {
		super("granjero");
	}

}
