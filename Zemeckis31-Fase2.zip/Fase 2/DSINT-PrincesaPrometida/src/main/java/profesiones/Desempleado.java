package profesiones;

public class Desempleado extends Profesion {

	public Desempleado() {
		super("desempleado");
	}

}
