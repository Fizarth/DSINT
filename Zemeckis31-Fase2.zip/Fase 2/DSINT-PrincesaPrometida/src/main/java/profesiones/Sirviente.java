package profesiones;

public class Sirviente extends Profesion {

	public Sirviente() {
		super("sirviente");
	}

}
