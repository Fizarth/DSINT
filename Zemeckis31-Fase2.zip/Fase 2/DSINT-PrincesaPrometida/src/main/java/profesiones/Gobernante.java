package profesiones;

public class Gobernante extends Profesion {

	public Gobernante() {
		super("gobernante");
	}

}
