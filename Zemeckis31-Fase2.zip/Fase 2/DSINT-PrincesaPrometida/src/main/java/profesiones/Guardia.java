package profesiones;

public class Guardia extends Profesion {

	public Guardia() {
		super("guardia");
	}

}
