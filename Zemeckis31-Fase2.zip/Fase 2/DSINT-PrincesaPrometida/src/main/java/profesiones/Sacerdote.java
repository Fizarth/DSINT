package profesiones;

public class Sacerdote extends Profesion {

	public Sacerdote() {
		super("sacerdote");
	}

}
