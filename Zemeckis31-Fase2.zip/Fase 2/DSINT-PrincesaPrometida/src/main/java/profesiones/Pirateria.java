package profesiones;

public class Pirateria extends Profesion {

	public Pirateria() {
		super("pirateria");
	}

}
