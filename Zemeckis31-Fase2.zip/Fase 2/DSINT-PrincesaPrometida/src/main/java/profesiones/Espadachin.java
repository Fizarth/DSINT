package profesiones;

public class Espadachin extends Profesion {

	public Espadachin() {
		super("espadachin");
		// TODO Auto-generated constructor stub
	}

}
