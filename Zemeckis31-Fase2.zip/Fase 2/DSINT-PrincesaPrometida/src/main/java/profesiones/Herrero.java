package profesiones;

public class Herrero extends Profesion {

	public Herrero() {
		super("herrero");
	}

}
