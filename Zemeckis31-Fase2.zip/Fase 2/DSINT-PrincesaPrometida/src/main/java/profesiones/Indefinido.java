package profesiones;

public class Indefinido extends Profesion {

	public Indefinido() {
		super("indefinido");
	}

}
