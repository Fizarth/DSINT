package profesiones;

public class BrigadaBrutal extends Profesion {

	public BrigadaBrutal() {
		super("brigada brutal");
	}

}
