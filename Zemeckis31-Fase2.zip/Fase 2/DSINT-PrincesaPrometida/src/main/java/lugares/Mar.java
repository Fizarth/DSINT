package lugares;

public class Mar extends Lugar{

	public Mar(){
		super("Mar");
		// TODO Auto-generated constructor stub
	}

}
