package lugares;

public class HabitacionN extends Lugar{

	public HabitacionN() {
		super("Habitación del Niño");
		// TODO Auto-generated constructor stub
	}

}
