package lugares;

public class Espana extends Lugar {

	public Espana() {
		super("Espa�a");
	}

}
