package lugares;

public class PozoDesesperacion extends Lugar{

	public PozoDesesperacion() {
		super("Pozo de la Desesperaci�n");
	}

}
