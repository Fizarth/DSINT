package lugares;

public class CaminoMontana extends Lugar{

	public CaminoMontana() {
		super("Camido de la Monta�a");
		// TODO Auto-generated constructor stub
	}

}
