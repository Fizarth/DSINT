package lugares;

public class AcantiladosLocura extends Lugar {

	public AcantiladosLocura() {
		super("Acantilados de la Locura");
	}

}
