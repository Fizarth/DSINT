package lugares;

public class PantanoFuego extends Lugar{

	public PantanoFuego() {
		super("Pantano de Fuego");
		// TODO Auto-generated constructor stub
	}

}
