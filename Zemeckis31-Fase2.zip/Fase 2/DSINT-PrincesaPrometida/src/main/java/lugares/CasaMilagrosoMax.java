package lugares;

public class CasaMilagrosoMax extends Lugar{

	public CasaMilagrosoMax() {
		super("Casa del Milagroso Max");
	}

}
