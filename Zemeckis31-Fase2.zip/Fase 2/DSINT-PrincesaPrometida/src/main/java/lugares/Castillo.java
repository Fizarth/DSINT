package lugares;

public class Castillo extends Lugar{

	public Castillo() {
		super("Castillo");
		// TODO Auto-generated constructor stub
	}

}
