package lugares;

public class Granja extends Lugar{

	public Granja() {
		super("Granja");
	}

}
