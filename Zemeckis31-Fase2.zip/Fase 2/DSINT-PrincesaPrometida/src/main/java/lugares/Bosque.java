package lugares;

public class Bosque extends Lugar{

	public Bosque() {
		super("Bosque");
	}

}
