package lugares;

public class BosqueLadrones extends Lugar{

	public BosqueLadrones() {
		super("Boque de los Ladrones");
	}

}
