package utilidades;

public enum Sexo {
	HOMBRE, MUJER
}
