package utilidades;

public enum Origen {
	SICILIA, GROENLANDIA, ESPANA, FLORIN, GUILDER, CHICAGO, TURQUIA, INGLATERRA
}
