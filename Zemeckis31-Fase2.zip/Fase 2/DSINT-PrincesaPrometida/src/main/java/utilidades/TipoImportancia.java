package utilidades;

public enum TipoImportancia {
	SECUNDARIO, NARRADOR, PROTAGONISTA
}
