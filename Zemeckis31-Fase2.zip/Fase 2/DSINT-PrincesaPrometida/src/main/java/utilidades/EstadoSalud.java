package utilidades;

public enum EstadoSalud {
	ENFERMO, VIVO, BORRACHO, MUERTO, MEDIO_MUERTO, EN_PELIGRO, INCONSCIENTE
}
