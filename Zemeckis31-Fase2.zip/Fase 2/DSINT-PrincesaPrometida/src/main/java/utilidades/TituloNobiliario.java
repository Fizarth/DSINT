package utilidades;

public enum TituloNobiliario {
	CONDE, REY, PRINCIPE
}
