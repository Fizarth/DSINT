package utilidades;

public enum EstadoCivil {
	SOLTERO, CASADO, INDEFINIDO
}
