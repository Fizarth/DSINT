package utilidades;

public interface Consulta {

	public String getTipo();
	
}
