package relaciones;

import personajes.*;

public class ConoceA extends Relacion{
	
	public ConoceA(Personaje afect) {
		super("conoce a", afect);
	}
	
	
	

}
