package relaciones;

import personajes.*;

public class OdiaA extends Relacion {

	public OdiaA(Personaje afectado) {
		super("odia a", afectado);
	}

}
