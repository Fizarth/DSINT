package relaciones;

import personajes.*;

public class QuiereA extends Relacion {

	public QuiereA(Personaje afectado) {
		super("quiere a", afectado);
	}

}
