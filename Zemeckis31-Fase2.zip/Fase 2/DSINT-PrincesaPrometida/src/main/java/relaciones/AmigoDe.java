package relaciones;

import personajes.*;

public class AmigoDe extends Relacion {

	public AmigoDe(Personaje amigo) {
		super("amigo de", amigo);
	}

}
