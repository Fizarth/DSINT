package relaciones;

import personajes.*;

public class FamiliarDe extends Relacion {

	public FamiliarDe(Personaje familiar) {
		super("familiar de", familiar);
	}

}
