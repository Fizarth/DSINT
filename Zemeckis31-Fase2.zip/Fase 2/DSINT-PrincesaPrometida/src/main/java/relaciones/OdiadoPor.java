package relaciones;

import personajes.*;

public class OdiadoPor extends Relacion {

	public OdiadoPor(Personaje emisor) {
		super("odiado por", emisor);
	}

}
