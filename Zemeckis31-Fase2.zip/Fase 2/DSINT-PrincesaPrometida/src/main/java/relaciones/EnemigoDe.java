package relaciones;

import personajes.*;

public class EnemigoDe extends Relacion {

	public EnemigoDe(Personaje afectado) {
		super("enemigo de", afectado);
	}

}
