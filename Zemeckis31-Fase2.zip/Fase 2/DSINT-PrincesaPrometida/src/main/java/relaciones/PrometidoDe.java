package relaciones;

import personajes.*;

public class PrometidoDe extends Relacion {

	public PrometidoDe(Personaje prometida) {
		super("prometido de", prometida);
		// TODO Auto-generated constructor stub
	}

}
