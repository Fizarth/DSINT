package relaciones;

import personajes.*;

public class ConocidoDe extends Relacion{

	public ConocidoDe(Personaje emisor) {
		super("conocido de", emisor);
	}

}
