package relaciones;

import personajes.*;

public class PrometidaDe extends Relacion {

	public PrometidaDe(Personaje prometido) {
		super("prometida de", prometido);
	}

}
